#!/usr/bin/env python
"""Filter each language's XL-Sum split down to sports articles using the URL
keyword heuristic (documented explicitly, since XL-Sum has no category field).

Runs entirely offline (reads local disk saved by 01_download_all.py). Safe on
either node, but intended to run right after the copy onto the GPU node.

Applies the feasibility gate from the original 1-hour test plan: if a
language has fewer than `min_articles_per_language` sports articles in the
test split, it's flagged loudly rather than silently included.
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from utils.io_utils import get_logger, load_config, resolve_path, write_jsonl  # noqa: E402


def is_sports_url(url: str, keywords: list[str]) -> bool:
    if not url:
        return False
    url_lower = url.lower()
    return any(kw in url_lower for kw in keywords)


def filter_language(cfg: dict, lang: dict, logger) -> dict:
    from datasets import load_from_disk

    raw_dir = resolve_path(cfg, "data_dir", "xlsum_raw", lang["code"])
    if not raw_dir.exists():
        raise FileNotFoundError(
            f"No raw XL-Sum data for {lang['code']} at {raw_dir}. "
            f"Run 01_download_all.py on the CPU node first."
        )
    ds = load_from_disk(str(raw_dir))
    keywords = cfg["xlsum"]["sports_url_keywords"]
    seed = cfg["xlsum"]["random_seed"]
    max_test = cfg["xlsum"]["max_test_articles_per_language"]
    min_required = cfg["xlsum"]["min_articles_per_language"]

    counts = {}
    filtered_splits = {}
    for split_name in ds.keys():
        split = ds[split_name]
        sports_rows = [row for row in split if is_sports_url(row.get("url", ""), keywords)]
        counts[split_name] = len(sports_rows)
        filtered_splits[split_name] = sports_rows

    logger.info(f"[{lang['code']}] sports article counts by split: {counts}")

    test_rows = filtered_splits.get("test", [])
    if len(test_rows) < min_required:
        logger.warning(
            f"[{lang['code']}] FEASIBILITY GATE FAILED: only {len(test_rows)} sports "
            f"test articles found (< {min_required} required). Consider swapping this "
            f"language for another Indic language with better sports coverage."
        )
    else:
        logger.info(
            f"[{lang['code']}] feasibility gate passed: {len(test_rows)} sports test articles."
        )

    rng = random.Random(seed)
    if len(test_rows) > max_test:
        test_rows = rng.sample(test_rows, max_test)
        logger.info(f"[{lang['code']}] subsampled test split to {max_test} articles (seed={seed}).")

    out_path = resolve_path(cfg, "data_dir", "sports_filtered", f"{lang['code']}_test.jsonl")
    write_jsonl(out_path, test_rows)
    logger.info(f"[{lang['code']}] wrote {len(test_rows)} filtered test articles -> {out_path}")

    return {"language": lang["code"], "counts_by_split": counts, "final_test_size": len(test_rows)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/pipeline.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    logger = get_logger("filter_sports", cfg)

    summary = [filter_language(cfg, lang, logger) for lang in cfg["languages"]]

    logger.info("=== Filtering summary ===")
    for row in summary:
        logger.info(row)


if __name__ == "__main__":
    main()
