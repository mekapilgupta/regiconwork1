#!/usr/bin/env python
"""Merges surface metrics, heuristic fact-consistency scores, and (if present)
LLM-judge verdicts into one table, computes correlations between surface
metrics and factuality signals, and writes outputs/final_report.md.

Runs anywhere (pandas/scipy/matplotlib only, no GPU/network needed).

Core outputs:
  1. outputs/merged_results.csv        <- one row per (system, language, id)
  2. outputs/correlation_table.csv     <- ROUGE/BERTScore/chrF vs fact metrics
  3. outputs/final_report.md           <- headline numbers + the central plot
  4. outputs/rouge_vs_factuality.png   <- scatter, the paper's Figure 1 candidate
"""
from __future__ import annotations

import argparse
import glob
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from utils.io_utils import REPO_ROOT, get_logger, load_config, read_jsonl, resolve_path  # noqa: E402


def load_surface_metrics(cfg: dict) -> "pd.DataFrame":
    import pandas as pd

    metrics_dir = REPO_ROOT / cfg["paths"]["outputs_dir"] / "metrics"
    rows = []
    for fpath in glob.glob(str(metrics_dir / "*__surface_metrics.jsonl")):
        fname = Path(fpath).stem.replace("__surface_metrics", "")
        system, lang_code = fname.split("__")
        for r in read_jsonl(fpath):
            rows.append(
                {
                    "system": system,
                    "language": lang_code,
                    "id": r.get("id"),
                    "rouge1": r.get("rouge1"),
                    "rouge2": r.get("rouge2"),
                    "rougeL": r.get("rougeL"),
                    "chrf": r.get("chrf"),
                    "bertscore_f1": r.get("bertscore_f1"),
                }
            )
    return pd.DataFrame(rows)


def load_fact_consistency(cfg: dict) -> "pd.DataFrame":
    import pandas as pd

    fc_dir = REPO_ROOT / cfg["paths"]["outputs_dir"] / "fact_consistency"
    rows = []
    for fpath in glob.glob(str(fc_dir / "*__consistency.jsonl")):
        for r in read_jsonl(fpath):
            row = {
                "system": r["system"],
                "language": r["language"],
                "id": r["id"],
                "winner_flip_suspected": r.get("winner_flip_suspected"),
            }
            for ft, vals in r["fact_consistency"].items():
                row[f"{ft}_precision"] = vals.get("precision")
                row[f"{ft}_recall"] = vals.get("recall")
            rows.append(row)
    return pd.DataFrame(rows)


def load_llm_judge(cfg: dict) -> "pd.DataFrame":
    import pandas as pd

    path = REPO_ROOT / cfg["paths"]["outputs_dir"] / "llm_judge_results.jsonl"
    if not path.exists():
        return pd.DataFrame(columns=["system", "language", "id", "verdict"])
    rows = [
        {"system": r["system"], "language": r["language"], "id": r["id"], "llm_verdict": r.get("verdict")}
        for r in read_jsonl(path)
    ]
    return pd.DataFrame(rows)


def main() -> None:
    import numpy as np
    import pandas as pd
    from scipy import stats

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/pipeline.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    logger = get_logger("analyze_results", cfg)

    surface = load_surface_metrics(cfg)
    facts = load_fact_consistency(cfg)
    judge = load_llm_judge(cfg)

    if surface.empty:
        logger.error("No surface metrics found. Run 04_surface_metrics.py first.")
        return

    merged = surface.merge(facts, on=["system", "language", "id"], how="left")
    merged = merged.merge(judge, on=["system", "language", "id"], how="left")

    merged_path = resolve_path(cfg, "outputs_dir", "merged_results.csv")
    merged.to_csv(merged_path, index=False)
    logger.info(f"Wrote merged results -> {merged_path}")

    # --- correlations: surface metrics vs. fact-consistency / LLM verdict ---
    surface_cols = ["rouge1", "rouge2", "rougeL", "chrf", "bertscore_f1"]
    fact_cols = [c for c in merged.columns if c.endswith("_precision") or c.endswith("_recall")]
    if "llm_verdict" in merged.columns and merged["llm_verdict"].notna().any():
        fact_cols.append("llm_verdict")

    corr_rows = []
    for sc in surface_cols:
        for fc in fact_cols:
            paired = merged[[sc, fc]].dropna()
            if len(paired) < 5:
                continue
            pearson_r, pearson_p = stats.pearsonr(paired[sc], paired[fc])
            spearman_r, spearman_p = stats.spearmanr(paired[sc], paired[fc])
            corr_rows.append(
                {
                    "surface_metric": sc,
                    "fact_metric": fc,
                    "n": len(paired),
                    "pearson_r": pearson_r,
                    "pearson_p": pearson_p,
                    "spearman_r": spearman_r,
                    "spearman_p": spearman_p,
                }
            )
    corr_df = pd.DataFrame(corr_rows).sort_values("pearson_r")
    corr_path = resolve_path(cfg, "outputs_dir", "correlation_table.csv")
    corr_df.to_csv(corr_path, index=False)
    logger.info(f"Wrote correlation table -> {corr_path}")

    # --- winner flip rate by system/language ---
    flip_summary = (
        merged.groupby(["system", "language"])["winner_flip_suspected"]
        .apply(lambda s: s.dropna().mean() if s.notna().any() else np.nan)
        .reset_index(name="winner_flip_rate")
    )

    # --- headline plot: ROUGE-L vs. a fact-recall metric (winner-context recall
    # if present, else athlete_name_recall), colored by winner_flip_suspected ---
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        y_col = "winner_keyword_context_recall" if "winner_keyword_context_recall" in merged.columns else "athlete_name_recall"
        plot_df = merged.dropna(subset=["rougeL", y_col])
        if not plot_df.empty:
            fig, ax = plt.subplots(figsize=(7, 5))
            colors = plot_df["winner_flip_suspected"].map({True: "red", False: "steelblue"}).fillna("gray")
            ax.scatter(plot_df["rougeL"], plot_df[y_col], c=colors, alpha=0.6, s=20)
            ax.set_xlabel("ROUGE-L (surface overlap with reference)")
            ax.set_ylabel(f"{y_col} (fact preservation vs. source)")
            ax.set_title("ROUGE-L vs. fact preservation\n(red = suspected winner flip)")
            fig.tight_layout()
            plot_path = REPO_ROOT / cfg["paths"]["outputs_dir"] / "rouge_vs_factuality.png"
            fig.savefig(plot_path, dpi=150)
            logger.info(f"Wrote headline plot -> {plot_path}")
    except ImportError:
        logger.warning("matplotlib not available, skipping plot generation.")

    # --- final markdown report ---
    report_lines = [
        "# Final Report: Sports Summarization Factuality in Indic Languages",
        "",
        "## Winner-flip suspected rate by system/language",
        "",
        flip_summary.to_markdown(index=False),
        "",
        "## Surface metric vs. fact-consistency correlations",
        "",
        "Sorted ascending — the WEAKEST (closest to zero, or negative) correlations",
        "are the headline evidence that surface metrics fail to track factuality.",
        "",
        corr_df.to_markdown(index=False),
        "",
        "## Interpretation notes",
        "",
        "- `winner_flip_suspected` is a heuristic proximity signal from",
        "  06_fact_consistency.py, not a validated relation extractor. Cross-check",
        "  against `llm_verdict` (if the phase-3 budget-capped judge stage was run)",
        "  before quoting flip rates as a headline number.",
        "- Fact precision/recall are computed against the SOURCE ARTICLE, not the",
        "  reference summary, to avoid conflating model hallucination with known",
        "  XL-Sum reference \"extra information\" (Hasan et al. 2021).",
        "- A near-zero or negative correlation between ROUGE-L and a fact-recall",
        "  column is the paper's central empirical claim: standard metrics do not",
        "  track sports-fact preservation.",
    ]
    report_path = REPO_ROOT / cfg["analysis"]["output_report_md"]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(str(l) for l in report_lines), encoding="utf-8")
    logger.info(f"Wrote final report -> {report_path}")


if __name__ == "__main__":
    main()
