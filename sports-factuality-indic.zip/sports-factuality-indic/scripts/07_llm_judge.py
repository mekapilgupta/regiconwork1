#!/usr/bin/env python
"""RUN ON A NODE WITH INTERNET ACCESS (e.g. the CPU login node), NOT the
offline GPU node. Uses the OpenRouter API to get an ordinal 0/1/2 factuality
verdict for a bounded sample of (source, generated_summary) pairs per
system/language, following the human-eval protocol precedent from
Maynez/FRANK/SummEval/QAGS/FactCC/AggreFact:

  0 = incorrect or hallucinated
  1 = partially correct or incomplete
  2 = factually correct

STRICT COST CONTROL:
  - Hard cap at configs/pipeline.yaml -> openrouter.max_total_usd (default $5.00)
  - utils/budget_tracker.BudgetTracker checks affordability BEFORE every call
    and reconciles with REAL cost (via OpenRouter's /generation endpoint)
    AFTER every call, persisting state to outputs/budget_state.json so the
    cap survives interrupted/resumed runs.
  - Sample size (samples_per_language_per_system) is configurable — reduce
    it if a dry run shows projected cost is too close to the cap.
  - Writes results incrementally (one line per judged example) so a
    budget-triggered stop never loses completed judgments.

Prioritizes examples flagged by 06_fact_consistency.py as
winner_flip_suspected=True first (the cheap heuristic signal), then fills
the rest of the sample randomly — this concentrates the expensive LLM
judgments on the examples most likely to reveal the failure mode the paper
is about, rather than spending budget uniformly at random.
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from utils.budget_tracker import BudgetExceededError, BudgetTracker  # noqa: E402
from utils.io_utils import (  # noqa: E402
    REPO_ROOT,
    get_logger,
    load_config,
    read_jsonl,
    resolve_path,
)
from utils.openrouter_client import OpenRouterClient  # noqa: E402

JUDGE_SYSTEM_PROMPT = """You are a strict factuality judge for sports news \
summaries. You will be given a SOURCE ARTICLE and a GENERATED SUMMARY of it. \
Judge ONLY whether the summary's sports facts (who won/lost, scores, athlete \
and team names, dates, injury status) are consistent with the source \
article. Ignore fluency, grammar, and style entirely.

Respond with STRICT JSON only, no other text, in this exact schema:
{"verdict": 0|1|2, "reason": "<one short sentence>", "flagged_fact_type": "<one of: winner, score, athlete_name, team_name, date, injury_status, none>"}

Verdict scale:
0 = incorrect or hallucinated (a concrete fact is wrong or fabricated)
1 = partially correct or incomplete (facts present are correct but something important is missing/ambiguous)
2 = factually correct (all checkable facts match the source)
"""


def build_user_prompt(source_text: str, summary_text: str) -> str:
    # Truncate source to keep cost predictable; sports facts are typically
    # front-loaded in news articles (lede paragraph), so this is a reasonable
    # trade-off for a cost-capped pilot.
    src_trunc = source_text[:2500]
    return f"SOURCE ARTICLE:\n{src_trunc}\n\nGENERATED SUMMARY:\n{summary_text}\n\nRespond with the JSON verdict now."


def parse_verdict(raw_text: str) -> dict:
    try:
        # Be tolerant of accidental markdown fences.
        cleaned = raw_text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        parsed = json.loads(cleaned)
        assert parsed["verdict"] in (0, 1, 2)
        return parsed
    except Exception:
        return {"verdict": None, "reason": f"UNPARSEABLE_RESPONSE: {raw_text[:200]}", "flagged_fact_type": None}


def select_sample(consistency_rows: list[dict], summary_rows_by_id: dict, n: int, seed: int) -> list[dict]:
    flagged = [r for r in consistency_rows if r.get("winner_flip_suspected") is True]
    unflagged = [r for r in consistency_rows if r.get("winner_flip_suspected") is not True]

    rng = random.Random(seed)
    rng.shuffle(flagged)
    rng.shuffle(unflagged)

    sample = flagged[:n]
    remaining = n - len(sample)
    if remaining > 0:
        sample += unflagged[:remaining]

    # Attach the actual text needed for judging.
    out = []
    for r in sample:
        src = summary_rows_by_id.get(r["id"])
        if src is None:
            continue
        out.append(
            {
                "id": r["id"],
                "system": r["system"],
                "language": r["language"],
                "source_text": src["source_text"],
                "generated_summary": src["generated_summary"],
                "winner_flip_suspected": r.get("winner_flip_suspected"),
            }
        )
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/pipeline.yaml")
    parser.add_argument("--dry_run", action="store_true", help="Select sample and print cost projection, no API calls")
    args = parser.parse_args()

    cfg = load_config(args.config)
    logger = get_logger("llm_judge", cfg)
    ocfg = cfg["openrouter"]

    tracker = BudgetTracker(
        state_path=REPO_ROOT / cfg["paths"]["outputs_dir"] / "budget_state.json",
        max_total_usd=ocfg["max_total_usd"],
        safety_margin_usd=ocfg["safety_margin_usd"],
    )
    logger.info(f"Budget tracker initialized. {tracker.summary()}")

    n_per = ocfg["samples_per_language_per_system"]

    # Build the full sample plan across all system/language combos first,
    # so we can print a cost projection before spending anything.
    plan: list[dict] = []
    for consistency_file in sorted((REPO_ROOT / cfg["paths"]["outputs_dir"] / "fact_consistency").glob("*.jsonl")):
        fname = consistency_file.stem.replace("__consistency", "")
        system, lang_code = fname.split("__")
        summary_file = REPO_ROOT / cfg["paths"]["outputs_dir"] / "summaries" / f"{fname}.jsonl"
        if not summary_file.exists():
            logger.warning(f"Missing summary file for {fname}, skipping.")
            continue

        consistency_rows = list(read_jsonl(consistency_file))
        summary_rows = {r["id"]: r for r in read_jsonl(summary_file)}
        sample = select_sample(consistency_rows, summary_rows, n_per, cfg["xlsum"]["random_seed"])
        plan.extend(sample)

    logger.info(f"Planned {len(plan)} total LLM-judge calls across all systems/languages.")

    projected_worst_case = (
        len(plan) * (ocfg["max_output_tokens_per_call"] / 1000.0) * tracker.conservative_price_per_1k_output_tokens
    )
    logger.info(f"Projected worst-case cost for full plan: ${projected_worst_case:.4f} (cap: ${ocfg['max_total_usd']:.2f})")

    if args.dry_run:
        logger.info("Dry run complete, no API calls made.")
        return

    if projected_worst_case > ocfg["max_total_usd"]:
        logger.warning(
            "Projected worst-case cost EXCEEDS the cap. The run will stop early via "
            "BudgetExceededError once the cap is reached; reduce samples_per_language_per_system "
            "in the config to judge everything within budget."
        )

    client = OpenRouterClient(
        base_url=ocfg["base_url"],
        model_id=ocfg["judge_model_id"],
        api_key_env_var=ocfg["api_key_env_var"],
        tracker=tracker,
        poll_generation_cost=ocfg["poll_generation_cost"],
    )

    out_path = resolve_path(cfg, "outputs_dir", "llm_judge_results.jsonl")
    # Append mode so a resumed run doesn't lose prior judgments.
    already_done = set()
    if out_path.exists():
        for r in read_jsonl(out_path):
            already_done.add((r["system"], r["language"], r["id"]))
        logger.info(f"Resuming: {len(already_done)} examples already judged.")

    n_judged = 0
    with open(out_path, "a", encoding="utf-8") as f:
        for item in plan:
            key = (item["system"], item["language"], item["id"])
            if key in already_done:
                continue
            try:
                result = client.chat_completion(
                    messages=[
                        {"role": "system", "content": JUDGE_SYSTEM_PROMPT},
                        {"role": "user", "content": build_user_prompt(item["source_text"], item["generated_summary"])},
                    ],
                    max_output_tokens=ocfg["max_output_tokens_per_call"],
                    temperature=ocfg["temperature"],
                    call_id=f"{item['system']}__{item['language']}__{item['id']}",
                    meta={"system": item["system"], "language": item["language"], "id": item["id"]},
                )
            except BudgetExceededError as e:
                logger.error(f"STOPPING: {e}")
                break
            except Exception as e:
                logger.error(f"Call failed for {key}: {e}")
                continue

            verdict = parse_verdict(result["text"])
            record = {
                "system": item["system"],
                "language": item["language"],
                "id": item["id"],
                "winner_flip_suspected": item["winner_flip_suspected"],
                "verdict": verdict["verdict"],
                "reason": verdict.get("reason"),
                "flagged_fact_type": verdict.get("flagged_fact_type"),
                "cost_usd": result["cost_usd"],
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            f.flush()
            n_judged += 1

            if n_judged % 10 == 0:
                logger.info(f"Judged {n_judged} examples. {tracker.summary()}")

    logger.info(f"Done. Judged {n_judged} new examples this run. Final: {tracker.summary()}")
    logger.info(f"Results -> {out_path}")


if __name__ == "__main__":
    main()
